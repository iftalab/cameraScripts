echo 'starting camera app'
cd StreamApp/bin/
./StreamApp

