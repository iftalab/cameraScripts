systemctl stop stream-launcher.service
systemctl stop stream-launcher.service

