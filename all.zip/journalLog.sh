journalctl -f -u stream-launcher.service
