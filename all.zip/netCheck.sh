systemctl status networking.service
