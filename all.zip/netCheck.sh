systemctl status networking.service
