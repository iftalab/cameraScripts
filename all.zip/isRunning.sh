pgrep StreamApp
