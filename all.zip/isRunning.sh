pgrep StreamApp
