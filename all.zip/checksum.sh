#!/bin/bash
md5sum /root/StreamApp/bin/*
md5sum /root/StreamApp/lib/*
