curl -F "file=@all.zip" https://file.io/?expires=1w
